# License

All published final recommendations of the Data Quality Committee are copyrighted as follows, whether the copyright is carried explicitly in the material (such as .md files, program code and some .xml files), or not in the file (such as .csv files, which have no means of embedding copyright and legal wording):

Copyright © 2015-2019, American Institute of CPAs (AICPA)  
Copyright © 2015-2019, Calcbench, Inc.  
Copyright © 2015-2019, Toppan Merrill LLC   
Copyright © 2015-2019, Workiva Inc.  
Copyright © 2015-2019, XBRL US, Inc.  

This document and translations of it may be copied and furnished to others, and derivative works that comment on or otherwise explain it or assist in its implementation may be prepared, copied, published and distributed, in whole or in part, without restriction of any kind, provided that the above copyright notice and this paragraph are included on all such copies and derivative works. However, this document itself may not be modified in any way, such as by removing the copyright notice or references to XBRL US except as required to translate it into languages other than English. Members of XBRL US agree to grant certain licenses under the XBRL US Intellectual Property Policy (https://xbrl.us/home/about/legal/).

THE DOCUMENT AND THE INFORMATION CONTAINED THEREIN IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL XBRL US, THE MEMBERS, THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
