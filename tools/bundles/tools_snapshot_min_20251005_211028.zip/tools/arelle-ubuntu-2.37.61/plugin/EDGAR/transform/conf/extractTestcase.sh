#!/bin/bash
java -jar saxon9.jar tests.xml extractTestcase.xsl  > testcase.xml
