# Exception
class XodelException(Exception):
    pass

class XodelNotInClark(XodelException):
    pass