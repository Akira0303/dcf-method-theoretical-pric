### Disclaimer
Files in this conformance suite are provided for regression testing only.
Files may be copied from other sources (such as https://datacvr.virk.dk/) with their comments included and may or may not be modified for testing purposes.
No rights or responsibilities conveyed, assumed, or provided.
