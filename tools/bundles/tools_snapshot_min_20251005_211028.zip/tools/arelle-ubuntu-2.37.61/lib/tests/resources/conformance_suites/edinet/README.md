### Disclaimer
Files in this conformance suite are provided for regression testing only.
Files may be copied from other sources (such as https://disclosure2.edinet-fsa.go.jp/week0020.aspx) with their comments included and may or may not be modified for testing purposes.
No rights or responsibilities conveyed, assumed, or provided.
